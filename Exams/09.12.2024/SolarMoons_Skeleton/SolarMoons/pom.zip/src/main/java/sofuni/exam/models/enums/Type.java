package sofuni.exam.models.enums;

public enum Type {

    ICE_GIANT, GAS_GIANT, TERRESTRIAL, DWARF_PLANET
}
