package sofuni.exam.service.Impl;

import org.springframework.stereotype.Service;
import sofuni.exam.service.DiscovererService;
import java.io.IOException;

@Service
public class DiscovererServiceImpl implements DiscovererService {


    @Override
    public boolean areImported() {
        return false;
    }

    @Override
    public String readDiscovererFileContent() throws IOException {
        return null;
    }

    @Override
    public String importDiscoverers() throws IOException {
        return null;
    }
}
